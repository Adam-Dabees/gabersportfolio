import Image from "next/image";
import Link from "next/link";

import { AnimatePresence } from "framer-motion";

import FadeUp from "@/animation/fade-up";
import FadeRight from "@/animation/fade-right";
import heroProfileImg from "@/public/Screenshot_2025-09-17_at_3.53.19_PM-removebg-preview.png";

export default function AboutHero() {
  return (
    <div className="mx-auto mt-0 flex max-w-7xl flex-col items-center gap-6 px-6 pt-20 text-center sm:px-14 md:mt-20 md:px-20 lg:mt-0 lg:flex-row lg:text-left">
      <div className="w-full sm:w-1/2 md:w-2/3 lg:inline-block lg:h-full lg:w-1/2">
        <AnimatePresence>
          <FadeUp key="hero-image" duration={0.6}>
            <Image
              src={heroProfileImg}
              width={400}
              height={400}
              className="h-auto w-full px-0 xl:px-16"
              alt="Gaber Soltan - Aerospace Engineer"
              priority
            />
          </FadeUp>
        </AnimatePresence>
      </div>
      <div className="sm:1/2 mt-10 w-full lg:w-1/2">
        <AnimatePresence>
          <FadeUp key="title-greeting" duration={0.6}>
            <h1 className="text-6xl font-bold text-accent sm:text-7xl md:text-6xl lg:text-5xl xl:text-7xl">
              Hi, I&apos;m Gaber Soltan
            </h1>
          </FadeUp>
          <FadeUp key="description-1" duration={0.6} delay={0.2}>
            <p className="mt-8 text-base font-medium text-zinc-900 dark:text-zinc-300 sm:text-lg md:text-lg">
              I&apos;m in my fourth year of Aerospace Engineering at Toronto
              Metropolitan University. Most of my hands-on work has been in
              composites and structures: producing CAD in SolidWorks and CATIA
              V5 for moulds, jigs and fixtures on my university&apos;s rocketry
              team, laying up and vacuum-bagging carbon and glass fibre, and
              sizing structural parts with FEA in ANSYS.
            </p>
          </FadeUp>
          <FadeUp key="description-2" duration={0.6} delay={0.4}>
            <p className="mt-8 text-base font-medium text-zinc-900 dark:text-zinc-300 sm:text-lg md:text-lg">
              Explore my latest{" "}
              <Link href="/projects" className="underline underline-offset-4">
                <span className="text-accent">projects</span>
              </Link>
              , including a composite glider taken from load case to flight test
              under a 175 g mass limit, and an ANSYS mesh convergence study that
              exposed a stress concentration the coarser meshes had missed.
            </p>
          </FadeUp>
          <FadeRight
            key="hero-title"
            duration={0.6}
            delay={0.8}
            className="mr-0 mt-8 flex items-center justify-center gap-4 lg:mr-8 lg:justify-end"
          >
            <span className="text-lg font-medium text-foreground">
              Aerospace Engineering Student
            </span>
          </FadeRight>
        </AnimatePresence>
      </div>
    </div>
  );
}
